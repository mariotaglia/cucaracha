/* esto es un comentario */

#define CHAIN 1  /* 0 - Without polymer chains
                    1 - With polymer chains (monolayers)
                    2 - Grafted polymer chains
                    
                 */
#undef geometry 1 /* Select geometry 0 - Flat surface?
                                     1 - Long Cylinder (1D)
                                     2 - Square section nanochannel 
                                     3 - Short 2D Cylinder 
                  */
#undef VDW 


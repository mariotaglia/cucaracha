/* esto es un comentario */

#define VDW 0  
#define dimR 10
